plugins {
    id("com.android.application") version "9.4.0" apply false
    id("com.cefrium") version "0.19.0" apply false
}
