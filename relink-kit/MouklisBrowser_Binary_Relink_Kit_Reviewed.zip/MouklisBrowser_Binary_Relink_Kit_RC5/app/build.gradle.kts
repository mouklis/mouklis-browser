plugins {
    id("com.android.application")
    id("com.cefrium")
}
android {
    buildFeatures { buildConfig = true }
    namespace = "com.mouklis.browser.v2"
    compileSdk = 37
    defaultConfig {
        applicationId = "com.mouklis.browser.v2"
        minSdk = 29
        targetSdk = 33
        versionCode = 14
        versionName = "1.0"
        manifestPlaceholders["appLabel"] = "Mouklis Browser V2"
        ndk {
            val targetAbi = providers.gradleProperty("targetAbi").orNull
            require(targetAbi == null || targetAbi in listOf("x86_64", "arm64-v8a"))
            abiFilters += targetAbi?.let { listOf(it) } ?: listOf("x86_64", "arm64-v8a")
        }
    }
    buildTypes {
        // Dev build installs next to the OS-signed com.mouklis.browser.v2 on a running MouklisOS.
        // Release keeps its applicationId, label and signing unchanged.
        getByName("debug") {
            applicationIdSuffix = ".dev"
            manifestPlaceholders["appLabel"] = "Mouklis Browser Dev"
        }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    // LGPL Corresponding Application Code in COMPILED form (no Mouklis Java sources)
    implementation(files("libs/mouklis-app-bytecode.jar"))
    implementation("com.cefrium:cefrium-sdk:0.19.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.mediarouter:mediarouter:1.7.0")
    implementation("androidx.core:core:1.16.0")
    implementation("androidx.browser:browser:1.8.0")
}
