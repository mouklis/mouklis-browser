pluginManagement {
    repositories {
        // Optional: -PcefriumRepo=<path or URL of a Maven repository> resolves com.cefrium
        // from that repository first (rebuild against a modified Cefrium SDK, see README.md).
        providers.gradleProperty("cefriumRepo").orNull?.let { repo ->
            maven(repo) { content { includeGroup("com.cefrium") } }
        }
        maven("https://maven.cefrium.com") {
            content { includeGroup("com.cefrium") }
        }
        maven("https://codeberg.org/api/packages/cefrium/maven") {
            content { includeGroup("com.cefrium") }
        }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // Optional: -PcefriumRepo=<path or URL of a Maven repository> resolves com.cefrium
        // from that repository first.
        providers.gradleProperty("cefriumRepo").orNull?.let { repo ->
            maven(repo) { content { includeGroup("com.cefrium") } }
        }
        google()
        mavenCentral()
        maven("https://maven.cefrium.com") {
            content { includeGroup("com.cefrium") }
        }
        maven("https://codeberg.org/api/packages/cefrium/maven") {
            content { includeGroup("com.cefrium") }
        }
    }
}
rootProject.name = "MouklisBrowserV2"
include(":app")
