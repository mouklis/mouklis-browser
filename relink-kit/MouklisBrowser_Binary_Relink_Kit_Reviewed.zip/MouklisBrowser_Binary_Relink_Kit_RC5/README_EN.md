# Mouklis Browser v1.0 — Binary Application Relinking Materials (RC5 reviewed)

**Review/test artifact — not a certification of LGPL compliance.** Contains 69 compiled Mouklis application `.class` files, resources and Gradle configuration for building against Cefrium SDK 0.19.0. No original proprietary Java/Kotlin sources are included, but application bytecode **can be reverse engineered**.

## Building

Unzip, open a terminal in the kit directory and run `./gradlew :app:assembleRelease`. The wrapper honors `ANDROID_HOME` (or `ANDROID_SDK_ROOT`) and detects common macOS/Linux SDK locations; it needs a compatible JDK. Supply `ANDROID_HOME` and `JAVA_HOME` if auto-detection fails.

To relink against an interface-compatible modified Cefrium 0.19.0 Maven repository containing all required artifacts and the Gradle plugin marker:

```bash
./gradlew :app:assembleRelease -PcefriumRepo=/absolute/path/to/local/maven-repository --refresh-dependencies
```

Unsigned APK output: `app/build/outputs/apk/release/`. A build with unmodified Cefrium succeeded according to the included report. **Building with a modified Cefrium version, and runtime/install testing, remain unverified.** A separately signed APK may not update an installed one unless signatures match. Back up data before uninstalling an installed copy.

## Legal scope

The compiled application materials are intended to allow relinking in accordance with LGPLv3, including reverse engineering needed to debug modifications to the LGPL-covered library. They do not convey a general licence to Mouklis proprietary branding or unrelated app code. **Do not publish without project-owner approval.** A compliant distribution may additionally need Minimal Corresponding Source for the exact conveyed Cefrium libraries, appropriate licence notices, and applicable Installation Information. A successful build alone does not prove compliance.

Legal notices: https://github.com/mouklis/mouklis-browser
